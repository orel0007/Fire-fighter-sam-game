#pragma once
#include<iostream>
#include "GameObject.h"

void processCollision(GameObject& object1, GameObject& object2);