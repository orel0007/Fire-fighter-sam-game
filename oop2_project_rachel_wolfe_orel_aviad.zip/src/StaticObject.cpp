#include "StaticObject.h"

StaticObject::StaticObject()
{}
