#include "WoodWall.h"


WoodWall::WoodWall()
{}