#include "Wall.h"

Wall::Wall()
{}